package com.example.data.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

@IgnoreExtraProperties
data class Scrim(
    @DocumentId val id: String = "",
    val scrimId: String = "",
    val title: String = "",
    val date: String = "",
    val dayName: String = "",
    val dayNumber: Int = 0,
    val monthName: String = "",
    val time: String = "",
    val map: String = "",
    val maxTeams: Int = 20,
    val registeredTeams: Int = 0,
    val status: String = "open", // open, in_progress, completed, cancelled
    val statusLabel: String = "مفتوح التسجيل",
    val imageURL: String = "",
    val roomId: String = "",
    val roomPassword: String = "",
    val roomVisibleAt: String = "",
    val registeredUserIds: List<String> = emptyList(),
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)
