package com.example.ui.theme

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

// Primary Gold & Amber Accents
val GoldPrimary = Color(0xFFFFB800)
val GoldLight = Color(0xFFFFD54F)
val GoldDark = Color(0xFFD97706)
val AmberFire = Color(0xFFFF6F00)

// Deep Battlefield Backgrounds
val PubgBlack = Color(0xFF090806)
val PubgSurfaceDark = Color(0xFF13110D)
val PubgCardBg = Color(0xFF1A1713)
val PubgCardBorder = Color(0xFF3E331B)
val PubgInputBg = Color(0xDD171410)
val PubgInputBorder = Color(0xFF42371E)

// Status & Badge Colors
val ScrimGreen = Color(0xFF22C55E)
val ScrimGreenBg = Color(0x3322C55E)
val TournamentPurple = Color(0xFFA855F7)
val TournamentPurpleBg = Color(0x33A855F7)
val RedBadge = Color(0xFFEF4444)

// Neutral Text & Icons
val TextWhite = Color(0xFFFFFFFF)
val TextMuted = Color(0xFFA8A29E)
val TextDim = Color(0xFF78716C)

// Gradients
val GoldButtonGradient = Brush.horizontalGradient(
    colors = listOf(Color(0xFFFFD54F), Color(0xFFFFB300), Color(0xFFFF8F00))
)

val DarkCardGradient = Brush.verticalGradient(
    colors = listOf(Color(0xFF221E18), Color(0xFF15130F))
)

val GoldenBorderBrush = Brush.linearGradient(
    colors = listOf(Color(0xFFFFD54F), Color(0xFF6B531C), Color(0xFFFFB800))
)
