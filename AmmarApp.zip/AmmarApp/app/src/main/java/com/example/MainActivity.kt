package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import com.example.data.repository.AuthRepository
import com.example.data.repository.NotificationRepository
import com.example.data.repository.ScrimRepository
import com.example.data.repository.StatsRepository
import com.example.data.repository.TournamentRepository
import com.example.ui.auth.AuthScreen
import com.example.ui.components.OfflineBlockerScreen
import com.example.ui.home.HomeScreen
import com.example.ui.theme.MyApplicationTheme
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestore

import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.rememberCoroutineScope
import com.example.util.NetworkConnectivityMonitor
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                AppContent()
            }
        }
    }
}

@Composable
fun AppContent() {
    val context = LocalContext.current
    val databaseId = context.getString(R.string.firestore_database_id)
    val firestore = remember { FirebaseFirestore.getInstance(databaseId) }

    val networkMonitor = remember { NetworkConnectivityMonitor(context) }
    val authRepository = remember { AuthRepository(context, firestore) }
    val scrimRepository = remember { ScrimRepository(firestore) }
    val tournamentRepository = remember { TournamentRepository(firestore) }
    val notificationRepository = remember { NotificationRepository(firestore) }
    val statsRepository = remember { StatsRepository(firestore) }

    val currentSession by authRepository.currentSession.collectAsState()
    val isOnline by networkMonitor.isOnline.collectAsState()
    val coroutineScope = rememberCoroutineScope()
    var retryTrigger by remember { mutableStateOf(0) }

    if (!isOnline) {
        OfflineBlockerScreen(
            onRetry = {
                retryTrigger++
            }
        )
    } else if (currentSession == null) {
        AuthScreen(
            authRepository = authRepository,
            onAuthSuccess = {
                // Session is updated reactively in authRepository
            }
        )
    } else {
        val session = currentSession!!
        val uid = session.userId
        val isProfileIncomplete = session.inGameId.length != 10 || !session.inGameId.all { it.isDigit() }
        var isSavingGoogleProfile by remember { mutableStateOf(false) }

        key(uid) {
            HomeScreen(
                currentUserId = uid,
                networkMonitor = networkMonitor,
                authRepository = authRepository,
                scrimRepository = scrimRepository,
                tournamentRepository = tournamentRepository,
                notificationRepository = notificationRepository,
                statsRepository = statsRepository,
                onSignOut = {
                    authRepository.signOut(coroutineScope) {}
                }
            )

            if (isProfileIncomplete) {
                com.example.ui.components.GoogleProfileDialog(
                    initialName = session.inGameName.ifBlank { session.fullName },
                    isLoading = isSavingGoogleProfile,
                    onSaveProfile = { name, id ->
                        isSavingGoogleProfile = true
                        coroutineScope.launch {
                            authRepository.updateGooglePlayerProfile(name, id)
                            isSavingGoogleProfile = false
                        }
                    }
                )
            }
        }
    }
}
