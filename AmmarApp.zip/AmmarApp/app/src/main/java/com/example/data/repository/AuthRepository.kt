package com.example.data.repository

import android.app.Activity
import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import androidx.credentials.exceptions.NoCredentialException
import com.example.R
import com.example.data.model.UserProfile
import com.example.data.util.OperationType
import com.example.data.util.handleFirestoreError
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential.Companion.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.util.UUID

class AuthRepository(
    private val context: Context,
    private val firestore: FirebaseFirestore
) {
    private val auth: FirebaseAuth = Firebase.auth
    private val credentialManager = CredentialManager.create(context)
    private val prefs: SharedPreferences = context.getSharedPreferences("ammar_auth_prefs", Context.MODE_PRIVATE)

    private val _currentSession = MutableStateFlow<UserProfile?>(null)
    val currentSession: StateFlow<UserProfile?> = _currentSession.asStateFlow()

    init {
        // Restore initial session from local storage or Firebase Auth
        val savedJson = prefs.getString("active_session_profile", null)
        if (!savedJson.isNullOrBlank()) {
            try {
                val json = JSONObject(savedJson)
                _currentSession.value = UserProfile(
                    userId = json.optString("userId", UUID.randomUUID().toString()),
                    fullName = json.optString("fullName", "لاعب ببجي"),
                    username = json.optString("username", "player"),
                    inGameName = json.optString("inGameName", "لاعب ببجي"),
                    inGameId = json.optString("inGameId", "1234567890"),
                    email = json.optString("email", ""),
                    role = json.optString("role", "player"),
                    photoURL = json.optString("photoURL", null),
                    provider = json.optString("provider", "email")
                )
            } catch (e: Exception) {
                Log.w("Auth", "Failed to parse saved session profile", e)
            }
        }

        // Keep session synchronized with Firebase Auth
        auth.addAuthStateListener { firebaseAuth ->
            val user = firebaseAuth.currentUser
            if (user != null) {
                val existing = _currentSession.value
                val isAdmin = user.email == "youss3fmohmmed68@gmail.com"
                val profile = UserProfile(
                    userId = user.uid,
                    fullName = user.displayName ?: existing?.fullName ?: "لاعب ببجي",
                    username = user.email?.substringBefore("@") ?: existing?.username ?: "player",
                    inGameName = existing?.inGameName?.ifBlank { user.displayName } ?: "لاعب ببجي",
                    inGameId = existing?.inGameId?.ifBlank { user.uid.filter { it.isDigit() }.take(10).padEnd(10, '0') } ?: "1234567890",
                    email = user.email ?: existing?.email ?: "",
                    role = if (isAdmin) "admin" else (existing?.role ?: "player"),
                    photoURL = user.photoUrl?.toString() ?: existing?.photoURL,
                    provider = "google"
                )
                saveSessionLocally(profile)
            }
        }
    }

    val currentUser: FirebaseUser?
        get() = auth.currentUser

    fun observeAuthState(): Flow<FirebaseUser?> = callbackFlow {
        val listener = FirebaseAuth.AuthStateListener { firebaseAuth ->
            trySend(firebaseAuth.currentUser)
        }
        auth.addAuthStateListener(listener)
        awaitClose { auth.removeAuthStateListener(listener) }
    }

    fun observeCurrentSession(): StateFlow<UserProfile?> = currentSession

    private fun saveSessionLocally(profile: UserProfile) {
        _currentSession.value = profile
        try {
            val json = JSONObject().apply {
                put("userId", profile.userId)
                put("fullName", profile.fullName)
                put("username", profile.username)
                put("inGameName", profile.inGameName)
                put("inGameId", profile.inGameId)
                put("email", profile.email)
                put("role", profile.role)
                put("photoURL", profile.photoURL ?: "")
                put("provider", profile.provider)
            }
            prefs.edit().putString("active_session_profile", json.toString()).apply()
        } catch (e: Exception) {
            Log.w("Auth", "Failed to save session locally", e)
        }
    }

    suspend fun signInWithEmail(email: String, pass: String): Result<UserProfile> = withContext(Dispatchers.IO) {
        val trimmedEmail = email.trim().lowercase()
        val isAdminEmail = trimmedEmail == "youss3fmohmmed68@gmail.com"

        // Check if account is in local accounts registry
        val accountsJson = prefs.getString("registered_accounts", "{}") ?: "{}"
        val accountsObj = try { JSONObject(accountsJson) } catch (e: Exception) { JSONObject() }

        if (isAdminEmail) {
            // Organizer account - always accessible for Ammar Abu Daqa
            val adminProfile = UserProfile(
                userId = "admin_ammar_organizer",
                fullName = "عمار أبو دقه",
                username = "ammar_organizer",
                inGameName = "عمار أبو دقه",
                inGameId = "1234567890",
                email = trimmedEmail,
                role = "admin",
                provider = "email"
            )
            saveSessionLocally(adminProfile)
            return@withContext Result.success(adminProfile)
        }

        if (!accountsObj.has(trimmedEmail)) {
            return@withContext Result.failure(
                IllegalStateException("هذا البريد الإلكتروني غير مسجل، يرجى الانتقال لتبويب إنشاء حساب")
            )
        }

        val accountData = accountsObj.getJSONObject(trimmedEmail)
        val savedPassword = accountData.optString("password", "")
        if (savedPassword != pass) {
            return@withContext Result.failure(
                IllegalStateException("كلمة المرور غير صحيحة")
            )
        }

        val profile = UserProfile(
            userId = accountData.optString("userId", "player_${UUID.randomUUID().toString().take(8)}"),
            fullName = accountData.optString("inGameName", "لاعب ببجي"),
            username = accountData.optString("inGameId", "player"),
            inGameName = accountData.optString("inGameName", "لاعب ببجي"),
            inGameId = accountData.optString("inGameId", "1234567890"),
            email = trimmedEmail,
            role = accountData.optString("role", "player"),
            provider = "email"
        )
        saveSessionLocally(profile)
        Result.success(profile)
    }

    private val emailOtpService = com.example.data.service.EmailOtpService()

    suspend fun sendRegistrationOtp(email: String): Result<String> = withContext(Dispatchers.IO) {
        val trimmedEmail = email.trim().lowercase()
        if (trimmedEmail.isBlank() || !trimmedEmail.contains("@")) {
            return@withContext Result.failure(IllegalStateException("يرجى إدخال بريد إلكتروني صحيح"))
        }
        try {
            val code = emailOtpService.generateAndSendOtp(trimmedEmail)
            Result.success(code)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun verifyOtpAndRegister(
        gameName: String,
        gameId: String,
        email: String,
        pass: String,
        inputOtp: String
    ): Result<UserProfile> = withContext(Dispatchers.IO) {
        val trimmedEmail = email.trim().lowercase()
        val isValidOtp = emailOtpService.verifyOtp(trimmedEmail, inputOtp)
        if (!isValidOtp) {
            return@withContext Result.failure(
                IllegalStateException("رمز التحقق غير صحيح أو انتهت صلاحيته، يرجى إدخال الرمز الصحيح")
            )
        }

        registerWithEmail(
            gameName = gameName,
            gameId = gameId,
            email = trimmedEmail,
            pass = pass
        )
    }

    suspend fun registerWithEmail(
        gameName: String,
        gameId: String,
        email: String,
        pass: String
    ): Result<UserProfile> = withContext(Dispatchers.IO) {
        val trimmedEmail = email.trim().lowercase()
        val trimmedGameName = gameName.trim()
        val trimmedGameId = gameId.trim()

        if (trimmedGameId.length != 10 || !trimmedGameId.all { it.isDigit() }) {
            return@withContext Result.failure(
                IllegalStateException("آيدي اللاعب يجب أن يتكون من 10 أرقام فقط")
            )
        }

        val accountsJson = prefs.getString("registered_accounts", "{}") ?: "{}"
        val accountsObj = try { JSONObject(accountsJson) } catch (e: Exception) { JSONObject() }

        if (accountsObj.has(trimmedEmail) && trimmedEmail != "youss3fmohmmed68@gmail.com") {
            return@withContext Result.failure(
                IllegalStateException("هذا البريد الإلكتروني مسجل بالفعل، يرجى تسجيل الدخول")
            )
        }

        val isAdmin = trimmedEmail == "youss3fmohmmed68@gmail.com"
        val userId = if (isAdmin) "admin_ammar_organizer" else "player_${UUID.randomUUID().toString().take(8)}"

        val accountEntry = JSONObject().apply {
            put("userId", userId)
            put("inGameName", trimmedGameName.ifBlank { "لاعب ببجي" })
            put("inGameId", trimmedGameId)
            put("email", trimmedEmail)
            put("password", pass)
            put("role", if (isAdmin) "admin" else "player")
        }
        accountsObj.put(trimmedEmail, accountEntry)
        prefs.edit().putString("registered_accounts", accountsObj.toString()).apply()

        val newProfile = UserProfile(
            userId = userId,
            fullName = trimmedGameName.ifBlank { "لاعب ببجي" },
            username = trimmedGameId,
            inGameName = trimmedGameName.ifBlank { "لاعب ببجي" },
            inGameId = trimmedGameId,
            email = trimmedEmail,
            role = if (isAdmin) "admin" else "player",
            provider = "email"
        )

        saveSessionLocally(newProfile)

        // Asynchronously persist to Firestore if possible
        try {
            if (auth.currentUser != null) {
                saveUserProfile(newProfile)
            }
        } catch (ignored: Exception) {
            // Keep local profile valid
        }

        Result.success(newProfile)
    }

    suspend fun getUserProfile(uid: String): UserProfile? = withContext(Dispatchers.IO) {
        val active = _currentSession.value
        if (active != null && active.userId == uid) {
            return@withContext active
        }

        val docRef = firestore.collection("users").document(uid)
        try {
            val snapshot = docRef.get().await()
            if (snapshot.exists()) {
                val profile = snapshot.toObject(UserProfile::class.java)
                if (profile != null) {
                    _currentSession.value = profile
                }
                profile
            } else {
                active
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.GET, docRef.path)
            active
        }
    }

    suspend fun saveUserProfile(profile: UserProfile): Result<Unit> = withContext(Dispatchers.IO) {
        val uid = auth.currentUser?.uid ?: profile.userId.ifBlank {
            return@withContext Result.failure(IllegalStateException("معرف المستخدم غير متاح"))
        }
        val docRef = firestore.collection("users").document(uid)
        try {
            val gameName = profile.inGameName.ifBlank { profile.fullName.ifBlank { "لاعب ببجي" } }
            val gameId = profile.inGameId.ifBlank { profile.username.ifBlank { uid.take(8) } }
            val payload = mutableMapOf<String, Any?>(
                "userId" to uid,
                "inGameName" to gameName,
                "inGameId" to gameId,
                "fullName" to gameName,
                "username" to gameId,
                "email" to (profile.email.ifBlank { auth.currentUser?.email ?: "player@ammarscrims.com" }),
                "accountStatus" to "active",
                "role" to if (profile.email == "youss3fmohmmed68@gmail.com" || auth.currentUser?.email == "youss3fmohmmed68@gmail.com") "admin" else "player",
                "createdAt" to FieldValue.serverTimestamp(),
                "lastLoginAt" to FieldValue.serverTimestamp()
            )
            if (!profile.photoURL.isNullOrBlank()) payload["photoURL"] = profile.photoURL

            docRef.set(payload).await()
            saveSessionLocally(profile)
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun updateGooglePlayerProfile(gameName: String, gameId: String): Result<UserProfile> = withContext(Dispatchers.IO) {
        val current = _currentSession.value ?: return@withContext Result.failure(IllegalStateException("لا يوجد جلسة نشطة"))
        val trimmedName = gameName.trim()
        val trimmedId = gameId.trim()

        if (trimmedId.length != 10 || !trimmedId.all { it.isDigit() }) {
            return@withContext Result.failure(IllegalStateException("آيدي اللاعب يجب أن يتكون من 10 أرقام فقط"))
        }

        val updatedProfile = current.copy(
            inGameName = trimmedName.ifBlank { "لاعب ببجي" },
            inGameId = trimmedId,
            fullName = trimmedName.ifBlank { "لاعب ببجي" },
            username = trimmedId
        )

        saveSessionLocally(updatedProfile)
        try {
            saveUserProfile(updatedProfile)
        } catch (ignored: Exception) {}

        Result.success(updatedProfile)
    }

    fun onGoogleSignInClicked(
        activity: Activity,
        scope: CoroutineScope,
        onSuccess: (UserProfile) -> Unit,
        onError: (String) -> Unit,
        onCancelled: () -> Unit
    ) {
        val clientId = try {
            context.getString(R.string.default_web_client_id)
        } catch (e: Exception) {
            onError("إعدادات Google غير مكتملة")
            return
        }

        val googleIdOption = GetGoogleIdOption.Builder()
            .setFilterByAuthorizedAccounts(false)
            .setServerClientId(clientId)
            .setAutoSelectEnabled(false)
            .build()

        val request = GetCredentialRequest.Builder()
            .addCredentialOption(googleIdOption)
            .build()

        scope.launch {
            try {
                val result = credentialManager.getCredential(activity, request)
                val credential = result.credential
                if (credential is CustomCredential && credential.type == TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                    val googleIdToken = GoogleIdTokenCredential.createFrom(credential.data).idToken
                    val authCredential = GoogleAuthProvider.getCredential(googleIdToken, null)
                    val authResult = auth.signInWithCredential(authCredential).await()
                    val user = authResult.user
                    if (user != null) {
                        val isAdmin = user.email == "youss3fmohmmed68@gmail.com"
                        val existingProfile = getUserProfile(user.uid)
                        val finalProfile = existingProfile ?: UserProfile(
                            userId = user.uid,
                            fullName = user.displayName ?: "لاعب ببجي",
                            username = (user.email?.substringBefore("@") ?: "Player_${user.uid.take(6)}"),
                            inGameName = user.displayName ?: "لاعب ببجي",
                            inGameId = user.uid.take(8),
                            email = user.email ?: "",
                            photoURL = user.photoUrl?.toString(),
                            provider = "google",
                            role = if (isAdmin) "admin" else "player"
                        )
                        if (existingProfile == null) {
                            try { saveUserProfile(finalProfile) } catch (ignored: Exception) {}
                        }
                        saveSessionLocally(finalProfile)
                        onSuccess(finalProfile)
                    } else {
                        onError("فشل جلب بيانات المستخدم من Google")
                    }
                } else {
                    onError("نوع الاعتماد غير متوافق")
                }
            } catch (e: GetCredentialCancellationException) {
                Log.w("Auth", "Google Sign-In cancelled: ${e.message}")
                onCancelled()
            } catch (e: NoCredentialException) {
                Log.w("Auth", "No Google account found on device: ${e.message}")
                onError("لم يتم العثور على حساب Google مسجل على هذا الهاتف أو المحاكي. يمكنك استخدام البريد الإلكتروني وكلمة المرور مباشرة.")
            } catch (e: Exception) {
                Log.e("Auth", "Google Sign-In error", e)
                val errorMsg = e.localizedMessage ?: ""
                if (errorMsg.contains("16:") || errorMsg.contains("Cannot find a matching credential")) {
                    onError("يرجى اختيار أو تسجيل حساب Google على الهاتف أولاً للمتابعة عبر Google.")
                } else {
                    onError("حدث خطأ أثناء الاتصال بخدمات Google: $errorMsg")
                }
            }
        }
    }

    fun signOut(
        scope: CoroutineScope,
        onComplete: () -> Unit
    ) {
        scope.launch {
            withContext(NonCancellable) {
                try {
                    credentialManager.clearCredentialState(ClearCredentialStateRequest())
                } catch (e: Exception) {
                    Log.w("Auth", "Failed to clear credential state: ${e.message}")
                } finally {
                    prefs.edit().remove("active_session_profile").apply()
                    _currentSession.value = null
                    auth.signOut()
                    onComplete()
                }
            }
        }
    }
}
